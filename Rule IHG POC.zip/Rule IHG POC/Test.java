package com.ags;

import java.util.Hashtable;

import javax.naming.AuthenticationException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;

public class Test {

	public static void main(String args[]) throws NamingException {

		Hashtable env = new Hashtable();
		env.put("java.naming.factory.initial",
				"com.sun.jndi.ldap.LdapCtxFactory");
		env.put("java.naming.security.principal", "test\\dsfadmin");
		env.put("java.naming.security.credentials", "pass@4444");
		env.put("java.naming.security.authentication", "Simple");
		env.put("java.naming.provider.url", "ldap://10.242.169.171:389");

		DirContext ctx = null;
		try {
			System.out.println("in try of autheticate method of ad conn");

			ctx = new InitialDirContext(env);
			System.out.println("connection" + ctx);
		} catch (AuthenticationException e) {
			System.out.println("authentication failed in ad conn");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String fname = "arjun";
		String lname = "sengupta";
		String fullName = null;
		
		String baseFullName=null;
		/*logic for username where lastname length is >=5,in that case we need to take 1st 5 character of lname 
		 * and 1st character of fname*/
		
		if(lname.length()>=5)
		{
			
			fullName = lname.substring(0,5) + fname.charAt(0);
	 
		boolean flag = true;
		String searchfilter = "cn=" + fullName;
		String searchbase = "ou=IHGEmp,dc=test,dc=com";
		SearchControls con = new SearchControls();
		con.setSearchScope(SearchControls.SUBTREE_SCOPE);
		NamingEnumeration answer1 = null;
		
		try {
			System.out.println("search filter==="+searchfilter);
			System.out.println("searchbase===+"+searchbase);
			answer1 = ctx.search(searchbase, searchfilter, con);
		 
		if (answer1.hasMore()) {
			System.out.println("arjun found");
			System.out.println("answe=="+answer1.hasMore());
			for (int i = 1; i <= fname.length() - 1; i++) {

				fullName = lname.substring(0,5)+fname.substring(0,i+1);

				searchfilter = "cn=" + fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (answer1.hasMoreElements()) {
					flag = false;
					continue;
				} else {
					flag = true;
					break;

				}
			}
		}
		}
		catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (flag == false) {
			String oldFullName=null;
			oldFullName=fullName;
			
			int j=1;
			while(true)
			{
				if(j<=9)
				{
				
				fullName=oldFullName+"0"+j;
				}
				else if(j>9)
				{
					fullName=oldFullName+j;
				}
				searchfilter = "cn="+fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(answer1.hasMore())
				{
					j++;
					continue;
				}
				else
				{
					break;
				}
			}
			
		}
	System.out.println("fullname=="+fullName);
	}
		
		/*logic for username where lastname does not contain 5 character we need to take rest 
		 * of the character from fname to make the length 6*/
		
		else if(lname.length()<5)
		{
			baseFullName=lname+fname.substring(0,(6-lname.length()));
			String searchfilter = "cn=" + baseFullName;
			String searchbase = "ou=IHGEmp,dc=test,dc=com";
			SearchControls con = new SearchControls();
			con.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration answer1 = null;
			boolean flag=false;
			try {
				answer1 = ctx.search(searchbase, searchfilter, con);
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (answer1 != null) {
			
			int	containedFirstNameLen=(6-lname.length());
			for(int i=1;i<=fname.length()-containedFirstNameLen;i++)
			{
				fullName=lname+fname.substring(0,containedFirstNameLen+i);
				searchfilter="cn=" +fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (answer1.hasMore()) {
					flag = false;
					continue;
				} else {
					flag = true;
					break;
				
			}
				
			}
			
			
			
			
		}
			
			if (flag == false) {
				String oldFullName=null;
				oldFullName=fullName;
				
				int j=1;
				while(true)
				{
					if(j<=9)
					{
					
					fullName=oldFullName+"0"+j;
					}
					else if(j>9)
					{
						fullName=oldFullName+j;
					}
					searchfilter = "cn="+fullName;
					try {
						answer1 = ctx.search(searchbase, searchfilter, con);
					} catch (NamingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(answer1.hasMore())
					{
						j++;
						continue;
					}
					else
					{
						break;
					}
				}
				
			}

		
}
}
}
