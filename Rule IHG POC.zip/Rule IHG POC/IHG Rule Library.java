<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE Rule PUBLIC "sailpoint.dtd" "sailpoint.dtd">
<Rule created="1460114375561" id="8a75418d53f475310153f59943890081" language="beanshell" modified="1461158870167" name="IHG Rule Library">
  <Description>Identity Correlation Rules are used to find identities to which new accounts can be attached.

A correlation rule must return a Map with one of the specified Return arguments.</Description>
  <Signature returnType="Map">
    <Inputs>
      <Argument name="log">
        <Description>
          The log object associated with the SailPointContext.
        </Description>
      </Argument>
      <Argument name="context">
        <Description>
          A sailpoint.api.SailPointContext object that can be used to query the database if necessary.
        </Description>
      </Argument>
      <Argument name="environment" type="Map">
        <Description>
          Arguments passed to the aggregation task.
        </Description>
      </Argument>
      <Argument name="application">
        <Description>
          Application being aggregated.
        </Description>
      </Argument>
      <Argument name="account">
        <Description>
          A sailpoint.object.ResourceObject returned from the
          collector.
        </Description>
      </Argument>
      <Argument name="link">
        <Description>
          Existing link to this account.
        </Description>
      </Argument>
    </Inputs>
    <Returns>
      <Argument name="identityName">
        <Description>
          The name of an Identity object.
        </Description>
      </Argument>
      <Argument name="identity">
        <Description>
          A fully resolved Identity object if the rule wants
          to do its own queries to locate the identity.
        </Description>
      </Argument>
      <Argument name="identityAttributeName">
        <Description>
          The name of the extended attribute that can be used
          to locate an existing identity.
        </Description>
      </Argument>
      <Argument name="identityAttributeValue">
        <Description>
          The value of the named extended attribute that can be used
          to locate an existing identity. This attribute is used
          together with the identityAttributeName argument.
        </Description>
      </Argument>
    </Returns>
  </Signature>
  <Source>
  import sailpoint.connector.Connector;
import sailpoint.connector.DelimitedFileConnector;
import sailpoint.object.Identity;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sailpoint.object.Attributes;
import sailpoint.object.Link;
import sailpoint.tools.GeneralException;
import sailpoint.object.Filter;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
import java.util.Calendar;
import java.util.Locale;
import java.util.StringTokenizer;
import sailpoint.api.PasswordGenerator;
import sailpoint.object.Application;
import sailpoint.object.Identity;
import sailpoint.object.EmailOptions;
import sailpoint.object.EmailTemplate;
import sailpoint.object.EmailFileAttachment;
import sailpoint.api.ObjectUtil;
import sailpoint.object.Configuration;
import sailpoint.object.Custom;

//Generate Email ID - Search on IDM
public String emailID(String lastName, String firstName) {
    QueryOptions options = new QueryOptions();
    String lastName = identity.getAttribute("lastname"); //fetching lastname from identity attribute
    String firstName = identity.getAttribute("firstname"); //fetching firstname from identity attribute
    String mail = identity.getAttribute("email"); //fetching email from identity attribute
    String fnameLname1 = "";
    int idExistCount = 0; // initializing a variable to store count value

    /*Logic to generate email id: &lt;firstname&lt;.&lt;lastname&lt;@ihg.com. If email id exists then &lt;firstname&lt;.&lt;lastname&lt;+,&lt;indexer&lt;@ihg.com */

    if (empID != null) {
        if (mail == null) {
            fnameLname1 = firstName + "." + lastName;
            mail = fnameLname1 + "@ihg.com";
            Identity relatedIdentityVar = null;
            options.addFilter(Filter.eq("email", mail));
            try {
                Iterator iterator = context.search(Identity.class, options);
                while (iterator.hasNext()) {
                    iterator.next();
                    idExistCount++;
                    mail = fnameLname1 + idExistCount.toString() + "@ihg.com";
                    try {
                        QueryOptions options1 = new QueryOptions();
                        options1.addFilter(Filter.eq("email", mail));
                        iterator = context.search(Identity.class, options1);
                    } catch (NamingException e) {
                        // TODO Auto-generated catch block
                        //e.printStackTrace();
                    }
                    if (iterator.hasNext()) {} else {
                        break;
                    }
                }
            } catch (Exception e) {
                //System.out.println("Error in searching---" + e);
            }
        }
    }
    return mail;
}

//Generate Network ID - Search on IDM
public String networkid(String firstName,String lastName)   {
   
QueryOptions options = new QueryOptions();
String lastName = identity.getAttribute("lastname"); //Fetching lastName from identity attribute
String firstName = identity.getAttribute("firstname"); //Fetching firstName from identity attribute
String networkID = identity.getAttribute("networkID"); //Fetching networkID from identity attribute
String fullName = ""; // String variable to store the created networkID
if (empID != null) {
    if (networkID == null) {
        /*logic for networkID where if lastName length is >=5,in that case we need to take 1st 5 character of lastName 
         * and 1st character of firstName*/
        if (lastName.length() >= 5) {
            fullName = lastName.substring(0, 5) + firstName.charAt(0);
            boolean flag = true;
            int i = 1;
            Identity relatedIdentityVar = null;
            options.addFilter(Filter.eq("networkID", fullName));
            try {
                Iterator iterator = context.search(Identity.class, options);
                while (iterator.hasNext()) {
                    iterator.next();
                    while (i &lt;= firstName.length() - 1) {
                        fullName = lastName.substring(0, 5) + firstName.substring(0, i + 1);
                        try {
                            QueryOptions options1 = new QueryOptions();
                            options1.addFilter(Filter.eq("networkID", fullName));
                            iterator = context.search(Identity.class, options1);
                        } catch (NamingException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        if (iterator.hasNext()) {
                            flag = false;
                        } else {
                            flag = true;
                            break;
                        }
                        i++;
                    }
                }
            } catch (Exception e) {
                System.out.println("Error in searching-------------------------------" + e);
            }
            if (flag == false) {
                String oldFullName = "";
                oldFullName = fullName;
                int j = 1;
                while (true) {
                    if (j &lt;= 9) {
                        fullName = oldFullName + "0" + j;
                    } else if (j > 9) {
                        fullName = oldFullName + j;
                    }

                    try {
                        QueryOptions options2 = new QueryOptions();
                        options2.addFilter(Filter.eq("networkID", fullName));
                        iterator = context.search(Identity.class, options2);
                    } catch (NamingException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    if (iterator.hasNext()) {
                        iterator = iterator.next();
                        j++;
                        continue;
                    } else {
                        break;
                    }
                }
            }
        }
        /*logic for networkID where lastName does not contain 5 character we need to take rest 
         * of the character from firstName to make the length 6*/
        else if (lastName.length() &lt; 5) {
            fullName = lastName + firstName.substring(0, (6 - lastName.length()));
            boolean flag = true;
            int containedFirstNameLen = (6 - lastName.length());
            int i = 1;
            Identity relatedIdentityVar = null;
            options.addFilter(Filter.eq("networkID", fullName));
            try {
                Iterator iterator = context.search(Identity.class, options);
                while (iterator.hasNext()) {
                    iterator.next();
                    while (i &lt;= (firstName.length() - containedFirstNameLen)) {
                        fullName = lastName + firstName.substring(0, containedFirstNameLen + i);
                        try {
                            QueryOptions options1 = new QueryOptions();
                            options1.addFilter(Filter.eq("networkID", fullName));
                            iterator = context.search(Identity.class, options1);
                        } catch (NamingException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        if (iterator.hasNext()) {
                            flag = false;
                        } else {
                            flag = true;
                            break;
                        }
                        i++;
                    }
                }
            } catch (Exception e) {
                System.out.println("Error in searching-------------------------------" + e);
            }

            if (flag == false) {
                String oldFullName = "";
                oldFullName = fullName;

                int j = 1;
                while (true) {
                    if (j &lt;= 9) {
                        fullName = oldFullName + "0" + j;
                    } else if (j > 9) {
                        fullName = oldFullName + j;
                    }

                    try {
                        QueryOptions options2 = new QueryOptions();
                        options2.addFilter(Filter.eq("networkID", fullName));
                        iterator = context.search(Identity.class, options2);
                    } catch (NamingException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    if (iterator.hasNext()) {
                        iterator = iterator.next();
                        j++;
                        continue;
                    } else {
                        break;
                    }
                }
            }
        }
       // map.put("networkID", fullName); // setting final value to networkID
    }
}
return fullName;
}

// Generate ManagerDN for AD provisioning
public String managerDN(Identity manager) {
    Identity manager = identity.getManager();
    String s = "";
    if (manager != null) {

        String key = manager.getAttribute("key");
        String location = manager.getAttribute("location");
        Custom allowedValues = context.getObjectByName(Custom.class, "place");
        String x = (String) allowedValues.get(location);
        s = "cn=" + key + "," + x;
    } else {
        s = " ";
    }
    return s;
}


public String mailID(String firstname, String lastname) {
    String identitycn = identity.getAttribute("firstname") + "." + identity.getAttribute("lastname");
    String identitymail = identitycn + "@IHG.com";
    int count = 0;
    Hashtable env = new Hashtable();
    env.put("java.naming.factory.initial",
        "com.sun.jndi.ldap.LdapCtxFactory");
    env.put("java.naming.security.principal", "test\\dsfadmin");
    env.put("java.naming.security.credentials", "pass@4444");
    env.put("java.naming.security.authentication", "Simple");
    env.put("java.naming.provider.url", "ldap://10.242.169.171:389");
    DirContext dctx = new InitialDirContext(env);
    String base = "OU=IHGMng,DC=test,DC=com";
    SearchControls sc = new SearchControls();
    String[] attributeFilter = {
        "cn",
        "sn",
        "ou",
        "givenName",
        "mail"
    };
    sc.setReturningAttributes(attributeFilter);
    sc.setSearchScope(SearchControls.SUBTREE_SCOPE);

    String filter = "(mail=" + identitymail + ")";
    found = true;
    while (found) {
        NamingEnumeration results = dctx.search(base, filter, sc);
        if (results.hasMore()) {
            // so we have one or more matches
            count++;
            identitycn = identity.getAttribute("lastname") + "." + identity.getAttribute("firstname") + count.toString();
            identitymail = identitycn + "@IHG.com";
            filter = "(mail=" + identitymail + ")";
        } else {
            // no match, continue
            found = false;
        }
    }

    dctx.close();
    return identitymail;
}

//Generate UserDN - AD provisioning
public String userDN(String fname,String lname) {

         Hashtable env = new Hashtable();
		env.put("java.naming.factory.initial",
				"com.sun.jndi.ldap.LdapCtxFactory");
		env.put("java.naming.security.principal", "test\\dsfadmin");
		env.put("java.naming.security.credentials", "pass@4444");
		env.put("java.naming.security.authentication", "Simple");
		env.put("java.naming.provider.url", "ldap://10.242.169.171:389");

		DirContext ctx = null;
		try {
			System.out.println("in try of autheticate method of ad conn");

			ctx = new InitialDirContext(env);
			System.out.println("connection" + ctx);
		} catch (AuthenticationException e) {
			System.out.println("authentication failed in ad conn");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  //Identity identity = context.getObjectByName(Identity.class, "306826"); 
		//String fname = "Sayani";
		//String lname = "Roy";
		String fname = identity.getAttribute("firstname");
		String lname =identity.getAttribute("lastname");
		String fullName = null;
		String str="";
		
		String baseFullName=null;
		/*logic for username where lastname length is >=5,in that case we need to take 1st 5 character of lname 
		 * and 1st character of fname*/
		
		if(lname.length()>=5)
		{
			
			fullName = lname.substring(0,5) + fname.charAt(0);
	 
		boolean flag = true;
		String searchfilter = "cn=" + fullName;
		String searchbase = "ou=IHGMng,dc=test,dc=com";
		SearchControls con = new SearchControls();
		con.setSearchScope(SearchControls.SUBTREE_SCOPE);
		NamingEnumeration answer1 = null;
		
		try {
			System.out.println("search filter==="+searchfilter);
			System.out.println("searchbase===+"+searchbase);
			answer1 = ctx.search(searchbase, searchfilter, con);
		 
		if (answer1.hasMore()) {
			System.out.println("arjun found");
			System.out.println("answe=="+answer1.hasMore());
			for (int i = 1; i &lt;= fname.length() - 1; i++) {

				fullName = lname.substring(0,5)+fname.substring(0,i+1);

				searchfilter = "cn=" + fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (answer1.hasMoreElements()) {
					flag = false;
					continue;
				} else {
					flag = true;
					break;

				}
			}
		}
		}
		catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (flag == false) {
			String oldFullName=null;
			oldFullName=fullName;
			
			int j=1;
			while(true)
			{
				if(j&lt;=9)
				{
				
				fullName=oldFullName+"0"+j;
				}
				else if(j>9)
				{
					fullName=oldFullName+j;
				}
				searchfilter = "cn="+fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(answer1.hasMore())
				{
					j++;
					continue;
				}
				else
				{
					break;
				}
			}
			
		}
	System.out.println("fullname=="+fullName);
	}
		
		/*logic for username where lastname does not contain 5 character we need to take rest 
		 * of the character from fname to make the length 6*/
		
		else if(lname.length()&lt;5)
		{
			System.out.println("basefullname........................."+fullName);
			fullName=lname+fname.substring(0,(6-lname.length()));
			String searchfilter = "cn=" + fullName;
			String searchbase = "ou=IHGEmp,dc=test,dc=com";
			SearchControls con = new SearchControls();
			con.setSearchScope(SearchControls.SUBTREE_SCOPE);
			NamingEnumeration answer1 = null;
			boolean flag=true;
			try {
				answer1 = ctx.search(searchbase, searchfilter, con);
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (answer1.hasMore()) {
				
			System.out.println("got first match.........................");
			int	containedFirstNameLen=(6-lname.length());
			for(int i=1;i&lt;=fname.length()-containedFirstNameLen;i++)
			{
				fullName=lname+fname.substring(0,containedFirstNameLen+i);
				searchfilter="cn=" +fullName;
				try {
					answer1 = ctx.search(searchbase, searchfilter, con);
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (answer1.hasMore()) {
					flag = false;
					continue;
				} else {
					flag = true;
					break;
				
			}
				
			}
			
			
			System.out.println("Fullname................................"+fullName);
			
		}
			
			if (flag == false) {
				String oldFullName=null;
				oldFullName=fullName;
				
				int j=1;
				while(true)
				{
					if(j&lt;=9)
					{
					
					fullName=oldFullName+"0"+j;
					System.out.println("Second Full name..............................."+fullName);
					}
					else if(j>9)
					{
						fullName=oldFullName+j;
					
					}
					searchfilter = "cn="+fullName;
					try {
						answer1 = ctx.search(searchbase, searchfilter, con);
					} catch (NamingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if(answer1.hasMore())
					{
						j++;
						continue;
					}
					else
					{
						break;
					}
				}
				
			}

		
}
identity.setAttribute("key", fullName);
 context.saveObject(identity);
                context.commitTransaction();
String valueOfKey = (String)identity.getAttribute("key");
System.out.println("valueeeeeeeeee offffffffffffffff keyyyyyyyyyyyyyyyyyyyy===========" +valueOfKey);	
 
					
					
					 String s =identity.getAttribute("location"); 
			String u =identity.getAttribute("type"); 
		Custom allowedValues = context.getObjectByName(Custom.class,"usertype");
		System.out.println("User Type --  "+ u);
		if(null != allowedValues)
		{   
		if(u.equals("manager"))
				{
						Map someKey1 = allowedValues.get("manager");
									System.out.println("User Type   "+ u);
		if(null != someKey1)
	  {
	String x=  (String)someKey1.get(s);
    str = "cn=" +fullName+","+x;
	}
   }
   else
   {
   Map someKey2 = allowedValues.get("employee");
System.out.println("User Type ---------------------  "+ u);
   if(null != someKey2)
	{
	String x=  (String)someKey2.get(s);
    str= "cn=" +fullName+","+x;
    }
   }
   }
			    ctx.close();
				return str;
      }

//Generate sAMAccountName - AD provisioning
public String sAMAccountName() {
    return identity.getAttribute("key");
}

//Generate givenName - AD provisioning
public String givenName() {
    return identity.getAttribute("firstname");
}

//Generate sn - AD provisioning
public String sn() {
    return identity.getAttribute("lastname");
}

//Generate displayName - AD provisioning
public String displayName() {
    return identity.getAttribute("key");
}

//Generate ObjectType - AD provisioning
public String ObjectType() {
    return "User";
}

//Generate password - AD provisioning
//public String password() {
    // return "Password-1"; //Its hardcoded 
    //return identity.getPassword();

//Generate password - AD provisioning	
public String Password()
{
    String pass = identity.getPassword();
    String DecryptPass = context.decrypt(pass);
	return DecryptPass;
  }
  </Source>
</Rule>
