import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.*;
import sailpoint.api.SailPointContext;
import sailpoint.connector.JDBCConnector;
import sailpoint.object.Application;
import sailpoint.object.Link;
import sailpoint.object.ProvisioningPlan;
import sailpoint.object.ProvisioningPlan.AccountRequest;
import sailpoint.object.ProvisioningPlan.AttributeRequest;
import sailpoint.object.ProvisioningPlan.PermissionRequest;
import sailpoint.object.ProvisioningResult;
import sailpoint.object.Schema;
import sailpoint.tools.xml.XMLObjectFactory;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import sailpoint.object.Identity;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.CallableStatement;
import com.mysql.jdbc.Connection;

//Log _log = LogFactory.getLog("RuleProvisionSampleDB");
public Map getAttributeRequestValue(List allAttributes) {
 String value = "";
 Map attrMap = new HashMap();
 for (AttributeRequest ar: allAttributes) {
  attrMap.put(ar.getName(), ar.getValue());
 }
 System.out.println("...............attrMap................." + attrMap);
 return attrMap;
}

void createGRSUser(AccountRequest account) {
 System.out.println("Operation [" + account.getOperation() + "] detected.");
 System.out.println(" ******* Plan ********* " + plan.toXml());
 System.out.println(" ******* Native Identity ********* " + plan.getNativeIdentity());
 account.setNativeIdentity(plan.getNativeIdentity());
 List allAttributes = account.getAttributeRequests();
 PreparedStatement statement = connection.prepareStatement("INSERT INTO GRS_Oracle.ihg_GRS(login,lastName,emailAddress,deleted,disabled,firstname,GRS_Entitlement,GRS_Updated) VALUES (?,?,?,?,?,?,?,?)");
 Map returnMap = getAttributeRequestValue(allAttributes);
 System.out.println(".............returnMap............." + returnMap);
 statement.setString(1, (String) plan.getNativeIdentity());
 if (returnMap.containsKey("lastname")) {
  statement.setString(2, returnMap.get("lastname"));
 } else {
  statement.setString(2, nullString);
 }
 if (returnMap.containsKey("emailAddress")) {
  statement.setString(3, returnMap.get("emailAddress"));
 } else {
  statement.setString(3, nullString);
 }
 if (returnMap.containsKey("deleted")) {
  statement.setString(4, returnMap.get("deleted"));
 } else {
  statement.setString(4, nullString);
 }
 if (returnMap.containsKey("disabled")) {
  statement.setString(5, returnMap.get("disabled"));
 } else {
  statement.setString(5, nullString);
 }
 if (returnMap.containsKey("firstname")) {
  statement.setString(6, returnMap.get("firstname"));
 } else {
  statement.setString(6, nullString);
 }
 if (returnMap.containsKey("GRS_ENTITLEMENT")) {
  statement.setString(7, returnMap.get("GRS_ENTITLEMENT"));
 } else {
  statement.setString(7, nullString);
 }
 if (returnMap.containsKey("GRS_Updated")) {
  statement.setString(8, returnMap.get("GRS_Updated"));
 } else {
  statement.setString(8, nullString);
 }
 statement.executeUpdate();
 result.setStatus(ProvisioningResult.STATUS_COMMITTED);
}

void updateGRSUser() {
 System.out.println("Entering Modify Operation");
 //_log.debug("Operation [" + account.getOperation() + "] detected.");
 /**PreparedStatement statement = connection.prepareStatement("update users set role = ? where login = ?");
 statement.setString(2, (String) account.getNativeIdentity());
 if (account != null) {
  AttributeRequest attrReq = account.getAttributeRequest("role");
  if (attrReq != null && ProvisioningPlan.Operation.Remove.equals(attrReq.getOperation())) {
   statement.setNull(1, Types.NULL);
   _log.debug("Preparing to execute:" + statement.toString());
   statement.executeUpdate();
  } else {
   statement.setString(1, attrReq.getValue());
   _log.debug("Preparing to execute:" + statement.toString());
   statement.executeUpdate();
  }
 }
 result.setStatus(ProvisioningResult.STATUS_COMMITTED);**/
}

if (plan != null) {
 List accounts = plan.getAccountRequests();
 System.out.println("All accounts: " + accounts);
 if ((accounts != null) && (accounts.size() > 0)) {
  for (AccountRequest account: accounts) {
   try {
    System.out.println("Account [" + account + "] detected.");
    if (AccountRequest.Operation.Create.equals(account.getOperation())) {
     createGRSUser(account);
     //Ideally we should first check to see if the account already exists.
     //As written, this just assumes it does not.
     //result.setObject(context.getObject(Identity.class,plan.getNativeIdentity()));  
    } else if (AccountRequest.Operation.Modify.equals(account.getOperation())) {
     // Modify account request -- change role
     updateGRSUser();
    } else {
     //Unknown operation!
     System.out.println("Unknown Operation");
    }
   } catch (SQLException e) {
    e.printStackTrace();
    result.setStatus(ProvisioningResult.STATUS_FAILED);
    result.addError(e);
   }
  }
 }
}
return result;