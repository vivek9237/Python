import java.util.*;
import sailpoint.object.*; 
import java.text.Normalizer; 
   import java.util.Hashtable;
import java.util.jar.Attributes;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

   String identitycn=identity.getAttribute("lastname")+identity.getAttribute("firstname");
 int count = 0;
  	    
	String userDn = "test\\dsfadmin";
	String adminPwd = "pass@4444";
	String INITCTX = "com.sun.jndi.ldap.LdapCtxFactory";
	String host = "ldap://10.242.169.171:389";
	Hashtable env = new Hashtable();
	env.put("java.naming.factory.initial", INITCTX);
	env.put("java.naming.provider.url", host);
	env.put("java.naming.security.authentication", "simple");
	env.put("java.naming.security.principal", userDn);
	env.put("java.naming.security.credentials", adminPwd);   
env.put(Context.REFERRAL, "follow");	
	DirContext dctx = new InitialDirContext(env);
			  System.out.println("context created");	
			
			    String base = "OU=IHGEmp,DC=test,DC=com";
			    System.out.println("context created==============================================================");	
			    SearchControls sc = new SearchControls();
			    String[] attributeFilter = { "cn","sn","ou","givenName"};
			    sc.setReturningAttributes(attributeFilter);
			    sc.setSearchScope(SearchControls.SUBTREE_SCOPE);

			    
					String filter = "(cn="+identitycn+")";
NamingEnumeration results = dctx.search(base, filter, sc);
  System.out.println("context created=========================gssgsgsggsghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh===----------------");	
					
					// Integer count = 0;
/*found = true;
//while (found) {
  
  */
  while (results.hasMore()) {
    // so we have one or more matches
    count++;
    
  } 
  identitycn=identity.getAttribute("lastname")+identity.getAttribute("firstname")+count.toString();

	  System.out.println("identitycn created=========================1111111111111111111111111111111111===----------------"+identitycn);	
 
 
					
					
					 String s =identity.getAttribute("location"); 
			String u =identity.getAttribute("Type"); 
		Custom allowedValues = context.getObjectByName(Custom.class,"usertype");
		System.out.println("User Type --  "+ u);
		if(null != allowedValues)
		{   
		if(u.equals("manager"))
				{
						Map someKey1 = allowedValues.get("manager");
									System.out.println("User Type   "+ u);
		if(null != someKey1)
	  {
	String x=  (String)someKey1.get(s);
    return "cn=" +identitycn+","+x;
	}
   }
   else
   {
   Map someKey2 = allowedValues.get("employee");
System.out.println("User Type ---------------------  "+ u);
   if(null != someKey2)
	{
	String x=  (String)someKey2.get(s);
    return "cn=" +identitycn+","+x;
    }
   }
   }
			    dctx.close();