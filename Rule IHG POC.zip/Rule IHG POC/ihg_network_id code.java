import sailpoint.connector.Connector;
import sailpoint.connector.Connector;
import sailpoint.connector.DelimitedFileConnector;
import sailpoint.object.Identity;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sailpoint.object.Application;
import sailpoint.object.Attributes;
import sailpoint.object.Link;
import sailpoint.tools.GeneralException;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;

import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import sailpoint.connector.DelimitedFileConnector;
import sailpoint.object.Identity;
import sailpoint.object.Filter;
import sailpoint.object.QueryOptions;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

import sailpoint.api.PasswordGenerator;
import sailpoint.object.Application;
import sailpoint.object.Identity;

import sailpoint.object.EmailOptions;
import sailpoint.object.EmailTemplate;
import sailpoint.object.EmailFileAttachment;
import sailpoint.object.Configuration;
import sailpoint.api.ObjectUtil;
import sailpoint.object.Configuration;

QueryOptions options = new QueryOptions();
HashMap map = DelimitedFileConnector.defaultBuildMap(cols, record);

String empID = (String) map.get("EmployeeID"); //Fetching EmployeeID from map
Identity identity = context.getObjectByName(Identity.class, empID); 
String lastName = identity.getAttribute("lastname"); //Fetching lastName from identity attribute
String firstName = identity.getAttribute("firstname"); //Fetching firstName from identity attribute
String networkID = identity.getAttribute("networkID"); //Fetching networkID from identity attribute
String fullName = ""; // String variable to store the created networkID
if (empID != null)
{
if (networkID == null) 
{
/*logic for networkID where if lastName length is >=5,in that case we need to take 1st 5 character of lastName 
		 * and 1st character of firstName*/
if(lastName.length()>=5)
{
fullName = lastName.substring(0,5) + firstName.charAt(0);
boolean flag = true;
int i=1;
Identity relatedIdentityVar = null;
options.addFilter(Filter.eq("networkID",fullName));
try 
{
Iterator iterator = context.search(Identity.class,options);
while (iterator.hasNext()) 
{
iterator.next();
while(i <= firstName.length() - 1)
{
fullName = lastName.substring(0,5)+firstName.substring(0,i+1);
try 
{
QueryOptions options1 = new QueryOptions();
options1.addFilter(Filter.eq("networkID",fullName));
iterator = context.search(Identity.class,options1);
} 
catch (NamingException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
if (iterator.hasNext()) 
{
flag = false;
}
else 
{
flag = true;
break;
}
i++;
}
} 
}
catch (Exception e)
{
System.out.println("Error in searching-------------------------------" + e);
}
if (flag == false) 
{
String oldFullName="";
oldFullName=fullName;
int j=1;
while(true)
{
if(j<=9)
{
fullName=oldFullName+"0"+j;
}
else if(j>9)
{
fullName=oldFullName+j;
}

try 
{
QueryOptions options2 = new QueryOptions();
options2.addFilter(Filter.eq("networkID",fullName));
iterator = context.search(Identity.class,options2);
} 
catch (NamingException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
if(iterator.hasNext())
{
iterator = iterator.next();
j++;
continue;
}
else
{
break;
}
}
}
}
/*logic for username where lastname does not contain 5 character we need to take rest 
		 * of the character from fname to make the length 6*/
else if (lastName.length() < 5)
 {
fullName = lastName + firstName.substring(0, (6 - lastName.length()));
boolean flag = true;
int containedFirstNameLen = (6 - lastName.length());
int i = 1;
Identity relatedIdentityVar = null;
options.addFilter(Filter.eq("networkID", fullName));
try 
{
Iterator iterator = context.search(Identity.class, options);
while (iterator.hasNext()) 
{
iterator.next();
while (i <= (firstName.length() - containedFirstNameLen)) 
{
fullName = lastName + firstName.substring(0, containedFirstNameLen + i);
try 
{
QueryOptions options1 = new QueryOptions();
options1.addFilter(Filter.eq("networkID", fullName));
iterator = context.search(Identity.class, options1);
} 
catch (NamingException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
if (iterator.hasNext())
 {
flag = false;
}
else
{
flag = true;
break;
}
i++;
}
}
}
catch (Exception e) 
{
System.out.println("Error in searching-------------------------------" + e);
}

if (flag == false)
{
String oldFullName = "";
oldFullName = fullName;

int j = 1;
while (true) 
{
if (j <= 9)
{
fullName = oldFullName + "0" + j;
} 
else if (j > 9) 
{
fullName = oldFullName + j;
}

try
{
QueryOptions options2 = new QueryOptions();
options2.addFilter(Filter.eq("networkID", fullName));
iterator = context.search(Identity.class, options2);
} 
catch (NamingException e) 
{
// TODO Auto-generated catch block
e.printStackTrace();
}
if (iterator.hasNext())
{
iterator = iterator.next();
j++;
continue;
}
else
{
break;
}
}
}
}
map.put("networkID",fullName); // setting final value to networkID
}
}
return map;